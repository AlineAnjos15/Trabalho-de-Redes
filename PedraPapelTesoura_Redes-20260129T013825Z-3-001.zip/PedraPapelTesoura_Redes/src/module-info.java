/**
 * 
 */
/**
 * 
 */
module PedraPapelTesoura_Redes {
}