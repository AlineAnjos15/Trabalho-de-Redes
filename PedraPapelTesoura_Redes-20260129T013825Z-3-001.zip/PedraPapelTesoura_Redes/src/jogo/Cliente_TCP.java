package jogo;

import java.io.*;
import java.net.*;

public class Cliente_TCP {
    
    public static void main(String[] args) {
        
        String servidor = "localhost"; 
        int porta = 3000; 
        try {
            Socket socket = new Socket(servidor, porta);
            System.out.println("conectado ao servidor de pedra papel e tesoura!");
            
            BufferedReader entradaservidor = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            DataOutputStream saidaservidor = new DataOutputStream(socket.getOutputStream()); 
            BufferedReader teclado = new BufferedReader( new InputStreamReader(System.in)); 
            
            Thread thread = new Thread(() -> { 
                try {
                    String mensagem; 
                    while ((mensagem = entradaservidor.readLine()) != null) {
                        System.out.println(mensagem);              
                    }
                } catch (Exception e) {
                    System.out.println("Conexão encerrada pelo servidor.");
                }
            });
            
            thread.start(); 
            String entrada;
            while (true) {
                entrada = teclado.readLine();
                if (entrada != null) {
                    saidaservidor.writeBytes(entrada + "\n");
                    if (entrada.equalsIgnoreCase("sair")) { 
                        System.out.println("voce saiu do jogo.");
                        break;
                    }
                }
            }
            socket.close();
            System.out.println("conexao fechada.");
            
        } catch (Exception e) {
            System.out.println("erro: " + e.getMessage());
            e.printStackTrace();
        }
    }
}