package jogo; 

import java.io.*;
import java.net.*;
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 
import java.util.*; 

public class Servidor_TCP {
	
	//método para enviar mensagens para todos os jogadores
	static void enviarmensagens(ArrayList<DataOutputStream> saidas, String mensagem) { 
        try {
            for (DataOutputStream out : saidas) { 
                out.writeBytes(mensagem + "\n"); 
            }
        } catch (Exception e) {
            System.out.println("erro: " + e.getMessage());
        }
    }
    //método para organizar e mostrar placar 
    static void mostrarPlacar(ArrayList<DataOutputStream> saidas, int[] pontos, int rodada) {
        enviarmensagens(saidas, "\nPLACAR:\nrodada: " + rodada +
            "\njogador 1: " + pontos[0] + " pontos" + 
            "\njogador 2: " + pontos[1] + " pontos" + 
            "\njogador 3: " + pontos[2] + " pontos\n");
    }
	//método para verificar o vencedor por rodada
    static ArrayList<Integer> vencedorrodada(Integer[] jogadas) {
        ArrayList<Integer> vencedores = new ArrayList<>();

        int pedras = 0, papeis = 0, tesouras = 0; 
        ArrayList<Integer> jogadorespedra = new ArrayList<>(); 
        ArrayList<Integer> jogadorespapel = new ArrayList<>();
        ArrayList<Integer> jogadorestesoura = new ArrayList<>();


        for (int i = 0; i < 3; i++) { 
            switch (jogadas[i]) { 
                case 1:
                    pedras++; 
                    jogadorespedra.add(i + 1);
                    break;
                case 2:
                    papeis++;
                    jogadorespapel.add(i + 1);
                    break;
                case 3:
                    tesouras++;
                    jogadorestesoura.add(i + 1);
                    break;
            }
        }
        if (pedras == 3 || papeis == 3 || tesouras == 3) return vencedores;
        if (pedras == 1 && papeis == 1 && tesouras == 1) return vencedores;
        if (pedras > 0 && tesouras > 0 && papeis == 0) { 
            vencedores.addAll(jogadorespedra); 
        } else if (papeis > 0 && pedras > 0 && tesouras == 0) {
            vencedores.addAll(jogadorespapel);
        } else if (tesouras > 0 && papeis > 0 && pedras == 0) {
            vencedores.addAll(jogadorestesoura);
        }
        return vencedores;
    }
    //método principal (
    public static void main(String[] args) throws Exception { 

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"); 
        int portaservidor = 3000;
        ServerSocket servidor = new ServerSocket(portaservidor); 
        System.out.println("servidor rodando na porta: "+ portaservidor);

        ArrayList<Socket> jogadores = new ArrayList<>();
        ArrayList<DataOutputStream> saidas = new ArrayList<>(); 
        ArrayList<BufferedReader> entradas = new ArrayList<>(); 

        while (jogadores.size() < 3) {
            Socket socket = servidor.accept(); 
            jogadores.add(socket);  
            saidas.add(new DataOutputStream(socket.getOutputStream()));
            entradas.add(new BufferedReader(new InputStreamReader(socket.getInputStream()))); 
            
            int id = jogadores.size(); 
            System.out.println("[" + dtf.format(LocalDateTime.now()) +  "] jogador " + id + " conectado");
            saidas.get(id - 1).writeBytes("jogador numero: " + id + "\n");
            enviarmensagens(saidas, "jogadores conectados: " + id + "/3");
        }

        boolean jogoAtivo = true; 
        while (jogoAtivo) { 
        	
            enviarmensagens(saidas, "\ndigite PRONTO para comecar ou SAIR para sair do jogo.");
            int confirmados = 0;
            boolean[] pronto = new boolean[3];
            
            while (confirmados < 3) {
                for (int i = 0; i < 3; i++) {
                    if (!pronto[i] && entradas.get(i).ready()) {
                        String msg = entradas.get(i).readLine(); 
                        if (msg.equalsIgnoreCase("PRONTO")) { 
                            pronto[i] = true;
                            confirmados++; 
                            enviarmensagens(saidas,
                                "jogador: " + (i + 1) + " pronto (" + confirmados + "/3)");
                        }
                    }
                } 
            }
            
            int[] pontos = new int[3]; 
            int rodada = 1; 
            while (rodada <= 5) {
                enviarmensagens(saidas, "\nrodada: " + rodada + "\n1 - PEDRA\n2 - PAPEL\n3 - TESOURA"+"\nescolha sua opcao:");
                Integer[] jogadas = new Integer[3]; 
                boolean[] jogou = new boolean[3];
                int recebidas = 0;
                while (recebidas < 3) {
                    for (int i = 0; i < 3; i++) {
                        if (!jogou[i] && entradas.get(i).ready()) {
                            String entrada = entradas.get(i).readLine();
                            switch (entrada) { 
                                case "1": 
                                	jogadas[i] = 1; 
                                	break;
                                case "2": 
                                	jogadas[i] = 2; 
                                	break;
                                case "3": 
                                	jogadas[i] = 3; 
                                	break;
                                default:
                                    saidas.get(i).writeBytes("escolha invalida, digite um numero\n");
                                    continue;
                            }
                            jogou[i] = true;
                            recebidas++;
                        }
                    }
                }
                
                ArrayList<Integer> vencedores =
                        vencedorrodada(jogadas); 
                if (vencedores.isEmpty()) {
                    enviarmensagens(saidas, "empate");
                } else {
                    for (int v : vencedores) { 
                        pontos[v - 1]++;
                        enviarmensagens(saidas,
                            "o jogador " + v + " ganhou 1 ponto"); 
                    }
                }
                
                mostrarPlacar(saidas, pontos, rodada);
                rodada++; 
            }

            enviarmensagens(saidas, "fim!"); 
            enviarmensagens(saidas, "deseja jogar novamente? (sim/nao)");
            boolean[] jogarnovamente = new boolean [3];
            int respostas=0;
            while(respostas<3) {
            	for(int i=0; i<3; i++) {
            		if(!jogarnovamente[i] && entradas.get(i).ready()) {
            			String resp = entradas.get(i).readLine();
            			if(resp.equalsIgnoreCase("SIM")) {
            				jogarnovamente[i] = true;
            				respostas++;
            			}else if(resp.equalsIgnoreCase("NAO")) {
            				enviarmensagens(saidas, "um jogador saiu, jogo fechado.");
            				jogoAtivo = false;
            				break;
            			}else {
            				saidas.get(i).writeBytes("digite apenas SIM ou NAO\n");
            			}
            			
            		}
            	}
            }
        }
        
        enviarmensagens(saidas, "servidor fechado"); 
        for (Socket s : jogadores) s.close(); 
        servidor.close();
    }
}